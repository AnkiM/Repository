﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.IO;

namespace TestApplication
{
    class Records
    {
        string _firstName;
        string _lastName;
        int _total;

        public string firstName { get { return this._firstName; } set { this._firstName = value; } }
        public string lastName { get { return this._lastName; } set { this._lastName = value; } }
        public int total { get { return this._total; } set { this._total = value; } }

        public Records(string firstname, string lastname, int total)
        {
            _firstName = firstname;
            _lastName = lastname;
            _total = total;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length <= 0)
                return;

            string file = args[0];
            //string file = @"D:\test.txt";

            if (File.Exists(file) == false)
            {
                Console.WriteLine("specified file does not exist");
                return;
            }

            Console.WriteLine("grade-scores "+file);
            
            try
            {
                string[] filedata = File.ReadAllLines(file);

                List<Records> RecordsList = new List<Records>();
                foreach (string record in filedata)
                {
                    string[] recorddata = record.Split(',');

                    if (recorddata.GetLength(0) < 3)
                        continue;
                    int count = Convert.ToInt32(recorddata[2]);

                    Records rd = new Records(recorddata[0], recorddata[1], count);
                    RecordsList.Add(rd);
                }

                var sortedData = RecordsList.OrderBy(x => x.total).ThenBy(x => x.firstName).ThenBy(x => x.lastName);

                string tempFilepath = file.Substring(0, file.Length - 4);
                string outputFile = tempFilepath + "-output.txt";

                using (StreamWriter sw = File.CreateText(outputFile))
                {
                    foreach (Records rd in sortedData)
                    {
                        Console.WriteLine(rd.firstName + "," + rd.lastName + "," + rd.total);
                        sw.WriteLine(rd.firstName + "," + rd.lastName + "," + rd.total);
                    }
                }

                Console.WriteLine("Finished: created "+outputFile);
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception occured " + e.Message);
            }

            Console.ReadLine();
        }
    }
}
